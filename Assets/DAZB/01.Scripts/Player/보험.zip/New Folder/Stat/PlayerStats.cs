[System.Serializable]
public class PlayerStats
{
    public float healthPoint;
    public float AttackSpeed;
    public float MoveSpeed;
    public float ATK;
    public float Defense;
    public float JumpPower;
    public float CriticalChance;
    public int maxDashCount;
}
